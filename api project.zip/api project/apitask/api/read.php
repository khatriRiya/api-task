<?php 
// headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

//inintalize our api
include_once('../core/initialize.php');

if(isset($_GET['key'])){
	$key= mysqli_real_escape_string($con, $_GET['key']);
	$checkRes= mysqli_query($con, "SELECT * FROM api_tocken WHERE tocken= '$key' ");
	if(mysqli_num_rows($checkRes) > 0){
		$checkRow= mysqli_fetch_assoc($checkRes);
		if($checkRow['status']==1){

			//check ip
			$ip= $_SERVER['REMOTE_ADDR'];
			$checkip= mysqli_query($con, "SELECT ip FROM api_tocken WHERE ip= '$ip' ");

			if(mysqli_num_rows($checkip) == 0){
				mysqli_query($con, "INSERT INTO api_tocken(id,tocken,status,hit_count,ip) VALUES(null, 'jsanksakslaksjlkasjklajsklajks','1','','$ip') ");

			}
			foreach($checkip as $myip)
			if($ip == $myip['ip']){
			mysqli_query($con, "UPDATE api_tocken set hit_count= hit_count+1 WHERE tocken= '$key' ");
			}

			//innitalize post

			$post= new Post($db);

			//blog post query

			$result= $post->read();
			$countresult= $post->apicount();

			//get the row count
			$num= $result->rowCount();
			$countnum= $countresult->rowCount();

			if($num > 0){
				
				while($row= $result->fetch(PDO::FETCH_ASSOC)){
					$post_arr[]= $row;
				}

				while($countrow= $countresult->fetch(PDO::FETCH_ASSOC)){
					$post_countarr[]= $countrow;
				}

				//convert to json  and output
				$dados1 = json_encode(['status'=> true, 'pdata'=>$post_arr, 'result'=> 'found']);
				$dados2 = json_encode(['status'=> true, 'cdata'=>$post_countarr, 'result'=> 'found']);

				echo json_encode(array_merge(json_decode($dados1, true),json_decode($dados2, true)));
			}
			else{
				echo json_encode( ['status'=> true, 'pdata'=>'No data found', 'result'=> 'Not Found'] );
			}

		}
		else{
			echo json_encode( ['status'=> false, 'pdata'=>'API Key Deactivated'] );
		}
			
	}
	else{
		echo json_encode( ['status'=> false, 'pdata'=>'Please Provide Valid API Key'] );
	}
	
}
else{
	echo json_encode( ['status'=> false, 'pdata'=>'Please Provide API Key'] );
}
