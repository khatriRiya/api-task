<?php 

$url= 'http://localhost/apitask/api/read.php?key=jsanksakslaksjlkasjklajsklajks';
$ch= curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
$result= curl_exec($ch);
curl_close($ch);
$result= json_decode($result, true);
//print_r($result);

if(isset($result['status'])){
	if($result['status']==true){
		if(isset($result['result'])){
			if($result['result']==true){
				?>
					<table>
						<tr>
							<td>ID</td>
							<td>Title</td>
							<td>Body</td>
							<td>Author</td>
							<td>Category Id</td>
							<td>Category Name</td>
						</tr>
						<?php 
						//print_r($result['pdata']);
							foreach($result['pdata'] as $list){
								echo "<tr>
									  <td> ".$list['id']."</td>
									  <td> ".$list['title']."</td>	
									  <td> ".$list['body']."</td>	
									  <td> ".$list['author']."</td>		
									  <td> ".$list['category_id']."</td>
									  <td> ".$list['category_name']."</td>	
									  </tr>";
							}
						?>
					</table>

					<?php 
						$sum=0;
						foreach($result['cdata'] as $list){
							$sum+= $list['hit_count'];
								
						}
						echo "<p> Total number of requests served: " . $sum . " </p>";
						foreach($result['cdata'] as $list){
								echo "<p> Total number of requests served By Partner".$list['id'].": " . $list['hit_count'] . " </p>";
						}

						echo "<lable>Select Date: </lable><select class='datetime' name='select_element'> <option>Select</option>";
						foreach($result['cdata'] as $list){
							echo "<p> Total number of requests served: " . $list['hit_count'] . " </p>";
							echo "<option value=" . $list['created_date'] . ">" . $list['created_date'] . "</option>";
						}
						echo "</select>";
						?>

					<?php
				
					
			}
			else{
				echo  $result['pdata'];
			}
		}
		else{
			echo  $result['pdata'];
		}
	}
	else{
			echo  $result['pdata'];
	}
}
else{
	echo 'API Not Working';
}


?>
