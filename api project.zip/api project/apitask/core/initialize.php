<?php 
  
  defined('DS') ? null : define('DS', DIRECTORY_SEPARATOR);
  defined('SITE_ROOT') ? null : define('SITE_ROOT', DS.'wordpress'.DS.'htdocs'.DS.'apitask');

  //wordpress/htdocs/apitask/includes
  defined('INC_PATH') ? null : define('INC_PATH', SITE_ROOT.DS.'includes');
  defined('CORE_PATH') ? null : define('CORE_PATH', SITE_ROOT.DS.'core');

  //load the config file first
  require_once(INC_PATH.DS."config.php");

  //core classes
  require_once(CORE_PATH.DS."api_data.php");

?>